import React from "react";

function Section1() {
  return (
    <div>
      <p>section1</p>
    </div>
  );
}

export default Section1;