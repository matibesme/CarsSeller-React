import React from "react";

function Section2() {
  return (
    <div>
     <p>section 2</p>
    </div>
  );
}

export default Section2;
