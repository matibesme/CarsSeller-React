import React from "react";

function Section3() {
  return (
    <div>
      <p>section3</p>
    </div>
  );
}

export default Section3;
